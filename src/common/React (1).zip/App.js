import React from 'react';
import ReactDOM from 'react-dom';
import Main_page from './Page/Main_page.js';

const App = () => {
  return (
    <React.Fragment>
    <Main_page/>
    
    </React.Fragment>

  );
}
export default App;