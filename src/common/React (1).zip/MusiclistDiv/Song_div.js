import React from 'react';
import ReactDOM from 'react-dom';

const Song_div = (props) => {
  return (
 
    <React.Fragment>
    <div className='eachbox_list' onClick={props.song_now}>{props.song_nb} . {props.song_name}</div>

    
    </React.Fragment>
  );
}
export default Song_div;