import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';

import Music_area from '../Components/Music_area.js';
import LastButton_div from '../Components/LastButton_div.js';
import Img_area from '../Components/img_area.js';
import Music_details from '../Components/Music_details.js';
import TopDiv from '../Components/TopDiv.js';
import SideDiv from '../Components/SideDiv.js';
import All_musics from '../MusiclistDiv/All_musics.js';


const Main_page = () => {


const [showMusicList, setShowMusicList] = useState(false);
  
const [showSideMenu, setShowSideMenu] = useState(false);



 const [musicArray,setMusicArray]=useState([]);
 
  const [musicUrl,setMusicUrl]=useState(null);
   

const [audio,setAudio]=useState((new Audio(musicUrl)));

const [audioPlaying, setAudioPlaying] = useState(false);


 const [playPauseIcon,setPlayPauseIcon]=useState("fa fa-play");
 
const [count,setCount]=useState(1);

const [divTarget,setDivTarget]=useState(null);

useEffect(() => {
 apiCallFunc();

  }, []);
 
 
 
const audioControl =() => {
  if(musicUrl==null){
    alert('please choose a song from musiclist');
  }
  else{
    if(audioPlaying==true){
      audio.pause();
      setAudioPlaying(false);
      setPlayPauseIcon("fa fa-play")
      }
    else{
      audio.play();
      setAudioPlaying(true);
      setPlayPauseIcon("fa fa-pause");
       }
    }
    
};
  

const currentSong = (url,e) => {
  if(audioPlaying==true){
    audio.pause();
    setAudioPlaying(false);
    setPlayPauseIcon("fa fa-play");
    
  };
  
  audio.src=url;
  audio.play();
  setAudioPlaying(true);
  setPlayPauseIcon("fa fa-pause");
  setMusicUrl(url);
  funcForDesign(e);
  
  
}

 const funcForDesign=(e)=>{

   if(count>=2){
    divTarget.style.backgroundColor="#CCCCCC";
    divTarget.style.boxShadow="1.5px 1.5px 5px #969697 inset";
    
  }
    
  e.target.style.backgroundColor="#A2A2A2";
  e.target.style.boxShadow="1px 1px 10px #3D3D3D inset";
  setDivTarget(e.target);
  setCount(count+1);
 
};

  
  const showList = () => {
    setShowMusicList(!showMusicList);

  };

  const cross = () => {
    setShowMusicList(!showMusicList);

  };
  
const sideMenu = () => {
    setShowSideMenu(!showSideMenu);
  }

const sideCross = () => {
    setShowSideMenu(!showSideMenu);
  }
  
 
 
const apiCallFunc = async () => {
    const response = await fetch('https://music-backend-new.herokuapp.com/get-list');
    const readResponce = await response.json();
    setMusicArray(readResponce.data);

  };
  
//const [indexNb,setIndexNb]=useState(null);

const randomSong=(maxNb)=>{
  if(audioPlaying==true){
    audio.pause();
    setAudioPlaying(false);
    setPlayPauseIcon("fa fa-play");
    
  };
  
  audio.src=(musicArray[(Math.floor(Math.random()*maxNb))].url);
  audio.play();
  setAudioPlaying(true);
  setPlayPauseIcon("fa fa-pause");
  setMusicUrl(musicArray[(Math.floor(Math.random()*maxNb))].url);
}


  return (
    <React.Fragment>
    <div className='container'>
      <TopDiv sidemenu={sideMenu}/>
      <Img_area/>
      <Music_details/>
      <Music_area/>
      <LastButton_div randomCall={()=>randomSong(musicArray.length)} startAudio={audioControl} showList={showList} icon={playPauseIcon}/>
     {
      showMusicList?<All_musics crossFunc={cross} currtSong={currentSong} music_array={musicArray}/>:null
      
    }

    {
       showSideMenu ? <SideDiv side_cross={sideCross}/> : null
    }
  
  
    </div>
  
  
    </React.Fragment>
  );
}
export default Main_page;