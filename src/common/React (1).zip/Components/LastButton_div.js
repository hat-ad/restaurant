import React from 'react';
import ReactDOM from 'react-dom';

const LastButton_div = (props) => {

  return (
    <React.Fragment>
    
      <div className='last_div'>
      <button>
        <i className="fa fa-random" onClick={props.randomCall}></i>
      </button>
      <button>
       <i className="fa fa-step-backward"></i>
      </button>
      <button>
        <i className={props.icon} onClick={props.startAudio}></i>
      </button>
      <button>
        <i className="fa fa-step-forward"></i>
       </button>
      <button>
        <i className="fa fa-music" onClick={props.showList}></i>
      </button>
      </div>
    </React.Fragment>
  );
}
export default LastButton_div;