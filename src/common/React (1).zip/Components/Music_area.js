import React from 'react';
import ReactDOM from 'react-dom';

const Music_area = () => {
  return (
    <React.Fragment>
       <div className='music_area'>
        <div className='slider_div'>
          <input type="range" className='input_range' min='0' max='100'/>
        </div>
   
        <div className='music_time'>
          <span>00:00</span>
          <span>02:30</span>
        </div>
      </div>
    </React.Fragment>
  )

}
export default Music_area;