import React from 'react';
import ReactDOM from 'react-dom';

const Img_area = () => {
  return (
    <React.Fragment>
    
      <div className="img_area">
         <div className="img_div">
           <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmbWNqEEHbsVJnLb4EAzQsvb27BXHnBxIpvg&usqpCAU"/>
         </div>
      </div>
    </React.Fragment>
  )

}
export default Img_area;