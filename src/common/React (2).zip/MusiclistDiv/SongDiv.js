import React from 'react';
import ReactDOM from 'react-dom';

const SongDiv = (props) => {
  return (
 
    <React.Fragment>
    <div className='eachbox_list' onClick={props.song_now}>{props.song_nb} . {props.song_name}</div>

    
    </React.Fragment>
  );
}
export default SongDiv;