import React from 'react';
import ReactDOM from 'react-dom';
import MainPage from './Page/MainPage.js';

const App = () => {
  return (
    <React.Fragment>
    <MainPage/>
    
    </React.Fragment>

  );
}
export default App;