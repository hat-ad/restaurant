import React from 'react';
import ReactDom from 'react-dom';

const MusicDetails = () => {
  return (
    <React.Fragment>
     <div className='music_details'>
         <span>Ankita santra</span>
         <span>***</span>
      </div>
    </React.Fragment>
  )
}
export default MusicDetails;