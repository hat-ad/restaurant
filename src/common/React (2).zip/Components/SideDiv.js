import React from 'react';
import ReactDOM from 'react-dom';

const SideDiv=(props)=>{
  return(
    <React.Fragment>
      <div className='side_div'>
        <div>
         <i className="fa fa-times" onClick={props.side_cross}></i>
        </div>
        <a href={props.musicLink} downlode><i className="fa fa-download"></i> downlode</a>
      </div>
    </React.Fragment>
    )
}
export default SideDiv;
