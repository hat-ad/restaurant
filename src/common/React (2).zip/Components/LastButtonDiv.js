import React from 'react';
import ReactDOM from 'react-dom';

const LastButtonDiv = (props) => {

  return (
    <React.Fragment>
    
      <div className='last_div'>
      <button>
        <i className="fa fa-random" onClick={props.randomCall}></i>
      </button>
      <button>
       <i className="fa fa-step-backward" onClick={props.backward}></i>
      </button>
      <button>
        <i className={props.icon} onClick={props.startAudio}></i>
      </button>
      <button>
        <i className="fa fa-step-forward" onClick={props.forward}></i>
       </button>
      <button>
        <i className="fa fa-music" onClick={props.showList}></i>
      </button>
      </div>
    </React.Fragment>
  );
}
export default LastButtonDiv;