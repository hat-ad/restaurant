import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';

import MusicArea from '../Components/MusicArea.js';
import LastButtonDiv from '../Components/LastButtonDiv.js';
import ImgArea from '../Components/ImgArea.js';
import MusicDetails from '../Components/MusicDetails.js';
import TopDiv from '../Components/TopDiv.js';
import SideDiv from '../Components/SideDiv.js';
import AllMusics from '../MusiclistDiv/AllMusics.js';


const MainPage = () => {


const [showMusicList, setShowMusicList] = useState(false);
  
const [showSideMenu, setShowSideMenu] = useState(false);



 const [musicArray,setMusicArray]=useState([]);
 
  const [musicUrl,setMusicUrl]=useState(null);
   

const [audio,setAudio]=useState((new Audio(musicUrl)));

const [audioPlaying, setAudioPlaying] = useState(false);


 const [playPauseIcon,setPlayPauseIcon]=useState("fa fa-play");
 
const [count,setCount]=useState(1);

const [divTarget,setDivTarget]=useState(null);
 
const [indexNb,setIndexNb]=useState(null);

useEffect(() => {
 apiCallFunc();

  }, []);
 
 

  const showList = () => {
    setShowMusicList(!showMusicList);

  };

  const cross = () => {
    setShowMusicList(!showMusicList);

  };
  
const sideMenu = () => {
    setShowSideMenu(!showSideMenu);
  }

const sideCross = () => {
    setShowSideMenu(!showSideMenu);
  }
  
  
   
const apiCallFunc = async () => {
    const response = await fetch('https://music-backend-new.herokuapp.com/get-list');
    const readResponce = await response.json();
    setMusicArray(readResponce.data);

  };
  
   
const audioControl =() => {
  if(musicUrl==null){
    alert('Please choose a song from musiclist/radomly');
  }
  else{
    if(audioPlaying==true){
      audio.pause();
      setAudioPlaying(false);
      setPlayPauseIcon("fa fa-play")
      }
    else{
      audio.play();
      setAudioPlaying(true);
      setPlayPauseIcon("fa fa-pause");
       }
    }
    
};
  

const currentSong = (url,index,e) => {
  if(audioPlaying==true){
    audio.pause();
    audio.src=url;
    audio.play();
    setMusicUrl(url);
    setIndexNb(index);
    funcForDesign(e);
    
  }
  else{
  
  audio.src=url;
  audio.play();
  setAudioPlaying(true);
  setPlayPauseIcon("fa fa-pause");
  setMusicUrl(url);
  setIndexNb(index);
  funcForDesign(e);
  
  }
}

 const funcForDesign=(e)=>{

   if(count>=2){
    divTarget.style.backgroundColor="#CCCCCC";
    divTarget.style.boxShadow="1.5px 1.5px 5px #969697 inset";
    
    }
    
  e.target.style.backgroundColor="#A2A2A2";
  e.target.style.boxShadow="1px 1px 10px #3D3D3D inset";
  setDivTarget(e.target);
  setCount(count+1);
 
};

  
  

const randomSong=(maxNb)=>{
  const ranNb=(Math.floor(Math.random()*maxNb));
  
  if(audioPlaying==true){
    audio.pause();
    audio.src=(musicArray[ranNb].url);
    audio.play();
    setIndexNb(ranNb);
    setMusicUrl(musicArray[ranNb].url);
    
  }
  else{
  
  audio.src=(musicArray[ranNb].url);
  audio.play();
  setAudioPlaying(true);
  setPlayPauseIcon("fa fa-pause");
  setIndexNb(ranNb);
  setMusicUrl(musicArray[ranNb].url);
  }
}
  


const backwardSong=()=>{
  
  if (musicUrl == null) {
    alert('Please choose music from musicList/radomly');
  }
  else{
    
   if (audioPlaying == true) {
     
     audio.pause();
     if(indexNb==0){
       audio.src=musicArray[(musicArray.length)-1].url;
      audio.play();
      setIndexNb((musicArray.length)-1);
      setMusicUrl(musicArray[(musicArray.length)-1].url);
      }
      else{
        
      audio.src = musicArray[indexNb - 1].url;
      audio.play();
      setIndexNb(indexNb-1);
      setMusicUrl(musicArray[indexNb - 1].url);
      }
      
    }
   else{
     if(indexNb==0){
     audio.src=musicArray[(musicArray.length)-1].url;
     audio.play();
     setAudioPlaying(true);
     setPlayPauseIcon("fa fa-pause");
     setIndexNb((musicArray.length)- 1);
     setMusicUrl(musicArray[(musicArray.length)- 1].url);
      }
      else{
     audio.src=musicArray[indexNb-1].url;
     audio.play();
     setAudioPlaying(true);
     setPlayPauseIcon("fa fa-pause");
     setIndexNb(indexNb-1);
     setMusicUrl(musicArray[indexNb-1].url);
      }
    };
  };
 
};

const forwardSong=()=>{
  
  if (musicUrl == null) {
    alert('Please choose music from musicList/radomly');
  }
  else{
    
   if (audioPlaying == true) {
     
     audio.pause();
     if(indexNb==(musicArray.length)-1){
       audio.src=musicArray[0].url;
       audio.play();
      setIndexNb(0);
      setMusicUrl(musicArray[0].url);
      }
      else{
        
      audio.src = musicArray[indexNb+1].url;
      audio.play();
      setIndexNb(indexNb+1);
      setMusicUrl(musicArray[indexNb + 1].url);
      }
      
    }
   else{
     if(indexNb==(musicArray.length)-1){
     audio.src=musicArray[0].url;
     audio.play();
     setAudioPlaying(true);
     setPlayPauseIcon("fa fa-pause");
     setIndexNb(0);
     setMusicUrl(musicArray[0].url);
      }
     else{
     audio.src=musicArray[indexNb+1].url;
     audio.play();
     setAudioPlaying(true);
     setPlayPauseIcon("fa fa-pause");
     setIndexNb(indexNb+1);
     setMusicUrl(musicArray[indexNb+1].url);
      }
    };
  };
 
};


  return (
    <React.Fragment>
    <div className='container'>
      <TopDiv sidemenu={sideMenu}/>
      <ImgArea/>
      <MusicDetails/>
      <MusicArea/>
      <LastButtonDiv randomCall={()=>randomSong(musicArray.length)} backward={backwardSong} forward={forwardSong} startAudio={audioControl} showList={showList} icon={playPauseIcon}/>
     {
      showMusicList?<AllMusics crossFunc={cross} currtSong={currentSong} music_array={musicArray}/>:null
      
    }

    {
       showSideMenu ? <SideDiv side_cross={sideCross} musicLink={musicUrl}/> : null
    }
  
  
    </div>
  
  
    </React.Fragment>
  );
}
export default MainPage;