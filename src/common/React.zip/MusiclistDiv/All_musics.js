import React, { useEffect } from 'react';
import ReactDOM from 'react-dom';
import Song_div from './Song_div.js';

const All_musics = (props) => {
 const array=props.music_array;
 console.log(array);
  return (
    <React.Fragment>
    <div className='musiclist_container'>
       <div className='list_header'>
          <i className="fa fa-bars"> music list</i>
          <i className="fa fa-times" onClick={props.crossFunc}></i>
      </div>
  
       
      <div className='music_list'>
        {array.map((obj,index)=>(
        <Song_div key={obj.id} song_name={obj.name} song_nb={index+1} song_now={(e)=>props.currtSong(obj.id,obj.url,e)}/>
        ))
      }
    </div>
  </div>
</React.Fragment>
  )
};
export default All_musics;