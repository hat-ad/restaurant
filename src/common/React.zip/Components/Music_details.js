import React from 'react';
import ReactDom from 'react-dom';

const Music_details = () => {
  return (
    <React.Fragment>
     <div className='music_details'>
         <span>Ankita santra</span>
         <span>***</span>
      </div>
    </React.Fragment>
  )
}
export default Music_details;