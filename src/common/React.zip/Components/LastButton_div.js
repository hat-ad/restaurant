import React from 'react';
import ReactDOM from 'react-dom';

const LastButton_div = (props) => {

  return (
    <React.Fragment>
    
      <div className='last_div'>
      <button>
        <i className="fa fa-random"></i>
      </button>
      <button>
       <i className="fa fa-step-backward"></i>
      </button>
      <button onClick={props.startAudio}>
        <i className="fa fa-play"></i>
      </button>
      <button>
        <i className="fa fa-step-forward"></i>
       </button>
      <button onClick={props.showList}>
        <i className="fa fa-music"></i>
      </button>
      </div>
    </React.Fragment>
  );
}
export default LastButton_div;