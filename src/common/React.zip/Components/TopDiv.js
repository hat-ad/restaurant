 import React from 'react';
 import ReactDOM from 'react-dom';

 const TopDiv = (props) => {
   return (
     <React.Fragment>
    <div className='top_div'>
      <i className="fa fa-angle-down"></i>
      <h4>Music Playing</h4>
      <i className="fa fa-ellipsis-h" onClick={props.sidemenu}></i>
    </div>
  </React.Fragment>
   )
 }

 export default TopDiv;