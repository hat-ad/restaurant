import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';

import Music_area from '../Components/Music_area.js';
import LastButton_div from '../Components/LastButton_div.js';
import Img_area from '../Components/img_area.js';
import Music_details from '../Components/Music_details.js';
import TopDiv from '../Components/TopDiv.js';
import SideDiv from '../Components/SideDiv.js';
import All_musics from '../MusiclistDiv/All_musics.js';


const Main_page = () => {


const [showMusicList, setShowMusicList] = useState(false);
  
const [showSideMenu, setShowSideMenu] = useState(false);



 const [musicArray,setMusicArray]=useState([]);
 
  const [musicUrl,setMusicUrl]=useState("https://res.cloudinary.com/ds7xxwtvb/video/upload/v1628136074/Gazab_Ka_Hai_Yeh_Din_-_Sanam_Re_Arijit_Singh_320Kbps_r8uim3.mp3");
   

useEffect(() => {
  apiCallFunc();
  
}, []);
  

let audio_playing=false;
const AudioControl = (e) => {
   const audio= new Audio(musicUrl);

    if (audio_playing == false) {
      audio.play();
      audio_playing=true;
      e.target.className="fa fa-pause";
    
    }
    else {
      audio.pause();
      audio_playing=false;
      e.target.className="fa fa-play";
    
    }
  
};

  const showList = () => {
    setShowMusicList(!showMusicList);

  };

  const cross = () => {
    setShowMusicList(!showMusicList);

  };
  
const sideMenu = () => {
    setShowSideMenu(!showSideMenu);
  }
  
const sideCross = () => {
    setShowSideMenu(!showSideMenu);
  }
  

const currentSong =(id,url,e)=>{
  const prevAudioUrl=musicUrl;
  console.log(prevAudioUrl);
  apiForUrl(id);
   console.log(url);
   if(prevAudioUrl!=url){
     AudioControl();
   }
  };
  
  const apiForUrl=async(id)=>{
    const resp=await fetch("https://music-backend-new.herokuapp.com/get-music/"+id);
    const readResp=await resp.json();
    setMusicUrl(readResp.data.url);
  }
 
  const apiCallFunc = async () => {
    const response = await fetch('https://music-backend-new.herokuapp.com/get-list');
    const readResponce = await response.json();
    setMusicArray(readResponce.data);

  };



  return (
    <React.Fragment>
    <div className='container'>
      <TopDiv sidemenu={sideMenu}/>
      <Img_area/>
      <Music_details/>
      <Music_area/>
      <LastButton_div startAudio={AudioControl} showList={showList}/>
     {
      showMusicList?<All_musics crossFunc={cross} currtSong={currentSong} music_array={musicArray}/>:null
      
    }

    {
       showSideMenu ? <SideDiv side_cross={sideCross}/> : null
    }
  
  
    </div>
  
  
    </React.Fragment>
  );
}
export default Main_page;